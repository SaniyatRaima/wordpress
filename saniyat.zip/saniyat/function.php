<?php 

add_theme_support('title-tag');
add_theme_support('custom-logo');

register_nav_menus(array(
    'menu-1'=>'primary menu',
));



