	<?php get_header();?>
	<div class="main-content">
		<div class="container">
			<div class="all-blogs">
				<div class="col-md-12">
					<div class="blog">
						<div class="blog-top">
							<img src="<?php echo get_template_directory_uri();?>/assets/images/01.jpg" alt="blog" />
						</div>
						
						<div class="blog-bottom">
							<h2>Title goes here</h2>
							<p>Continually maximize high-quality e-commerce for bleeding-edge systems. Enthusiastically parallel task vertical value vis-a-vis quality channels. Professionally extend wireless strategic theme areas and flexible ROI. Conveniently deploy tactical process improvements.</p>
							<a href="<?php echo get_template_directory_uri();?>/single.html" class="read-more-button">Continue Reading....</a>
						</div>
					</div>
					
					<div class="blog">
						<div class="blog-top">
							<img src="<?php echo get_template_directory_uri();?>/assets/images/02.jpg" alt="blog" />
						</div>
						
						<div class="blog-bottom">
							<h2>Title goes here</h2>
							<p>Continually maximize high-quality e-commerce for bleeding-edge systems. Enthusiastically parallel task vertical value vis-a-vis quality channels. Professionally extend wireless strategic theme areas and flexible ROI. Conveniently deploy tactical process improvements.</p>
							<a href="<?php echo get_template_directory_uri();?>/single.html" class="read-more-button">Continue Reading....</a>
						</div>
					</div>
					
					<div class="blog">
						<div class="blog-top">
							<img src="<?php echo get_template_directory_uri();?>/assets/images/02.png" alt="blog" />
						</div>
						
						<div class="blog-bottom">
							<h2>Title goes here</h2>
							<p>Continually maximize high-quality e-commerce for bleeding-edge systems. Enthusiastically parallel task vertical value vis-a-vis quality channels. Professionally extend wireless strategic theme areas and flexible ROI. Conveniently deploy tactical process improvements.</p>
							<a href="<?php echo get_template_directory_uri();?>/single.html" class="read-more-button">Continue Reading....</a>
						</div>
					</div>
					
					<div class="blog">
						<div class="blog-top">
							<img src="<?php echo get_template_directory_uri();?>/assets/images/03.jpg" alt="blog" />
						</div>
						
						<div class="blog-bottom">
							<h2>Title goes here</h2>
							<p>Continually maximize high-quality e-commerce for bleeding-edge systems. Enthusiastically parallel task vertical value vis-a-vis quality channels. Professionally extend wireless strategic theme areas and flexible ROI. Conveniently deploy tactical process improvements.</p>
							<a href="<?php echo get_template_directory_uri();?>/single.html" class="read-more-button">Continue Reading....</a>
						</div>
					</div>
					
					<div class="blog">
						<div class="blog-top">
							<img src="<?php echo get_template_directory_uri();?>/assets/images/02.png" alt="blog" />
						</div>
						
						<div class="blog-bottom">
							<h2>Title goes here</h2>
							<p>Continually maximize high-quality e-commerce for bleeding-edge systems. Enthusiastically parallel task vertical value vis-a-vis quality channels. Professionally extend wireless strategic theme areas and flexible ROI. Conveniently deploy tactical process improvements.</p>
							<a href="<?php echo get_template_directory_uri();?>/single.html" class="read-more-button">Continue Reading....</a>
						</div>
					</div>
					
					<div class="blog">
						<div class="blog-top">
							<img src="<?php echo get_template_directory_uri();?>/assets/images/01.jpg" alt="blog" />
						</div>
						
						<div class="blog-bottom">
							<h2>Title goes here</h2>
							<p>Continually maximize high-quality e-commerce for bleeding-edge systems. Enthusiastically parallel task vertical value vis-a-vis quality channels. Professionally extend wireless strategic theme areas and flexible ROI. Conveniently deploy tactical process improvements.</p>
							<a href="<?php echo get_template_directory_uri();?>/single.html" class="read-more-button">Continue Reading....</a>
						</div>
					</div>
					
					<div class="blog">
						<div class="blog-top">
							<img src="<?php echo get_template_directory_uri();?>/assets/images/02.jpg" alt="blog" />
						</div>
						
						<div class="blog-bottom">
							<h2>Title goes here</h2>
							<p>Continually maximize high-quality e-commerce for bleeding-edge systems. Enthusiastically parallel task vertical value vis-a-vis quality channels. Professionally extend wireless strategic theme areas and flexible ROI. Conveniently deploy tactical process improvements.</p>
							<a href="<?php echo get_template_directory_uri();?>/single.html" class="read-more-button">Continue Reading....</a>
						</div>
					</div>
					<div class="paginations">
						<a href="#">1</a>
						<a href="#">2</a>
						<a href="#" class="active">3</a>
						<a href="#">4</a>
						<a href="#">5</a>
					</div>
				</div>
			</div>
		</div>
	</div>

    <div class="footer">
		<div class="container">
			<div class="footer-text">
				<p>&copy; 2017- All Rights Reserved By: CodexCoder </p>
			</div>
		</div>
	</div>


     <?php get_footer();?>

