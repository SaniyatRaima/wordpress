    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="<?php echo get_template_directory_uri();?>/assets/js/jquery-3.2.1.min.js"></script>
    <script src="<?php echo get_template_directory_uri();?>/assets/js/popper.min.js"></script>
	<script src="<?php echo get_template_directory_uri();?>/assets/js/bootstrap.min.js"></script>
	<?php wp_footer();?>
  </body>
</html>
