<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

   <title>Example Of WordPress Site</title>

    <!-- Bootstrap core CSS -->
    <link href="assets/css/bootstrap.min.css" rel="stylesheet">
    <!-- Custom styles for this template -->
    <link href="assets/css/style.css" rel="stylesheet">
  </head>
  <body>

    <div class="header">
		<div class="container">
			  <nav class="navbar navbar-expand-lg navbar-light bg-light">
				  <a class="navbar-brand" href="index.html"><img src="assets/images/logo.png" alt="logo" /></a>
				  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
					<span class="navbar-toggler-icon"></span>
				  </button>

				  <div class="collapse navbar-collapse pull-right" id="navbarSupportedContent">
					<ul class="navbar-nav">
					  <li class="nav-item active">
						<a class="nav-link" href="index.html">Home <span class="sr-only">(current)</span></a>
					  </li>
					  <li class="nav-item">
						<a class="nav-link" href="single.html">Blog Single</a>
					  </li>
					  <li class="nav-item">
						<a class="nav-link" href="search.html">Search Page</a>
					  </li>
					  <li class="nav-item">
						<a class="nav-link" href="search-none.html">Search None</a>
					  </li>
					  <li class="nav-item">
						<a class="nav-link" href="archive.html">Archive</a>
					  </li>
					  <li class="nav-item">
						<a class="nav-link" href="404.html">404</a>
					  </li>
					</ul>
				  </div>
				</nav>
		</div>
	</div>
	
	<div class="page-header">
		<div class="container">
			<div class="page-header-text">
				<h3>You are searcing: <a href="">Search</a></h3>
			</div>
		</div>
	</div>
	
	<div class="main-content">
		<div class="container">
			<div class="all-blogs">
				<div class="row">
					<div class="col-md-8">
						<div class="blog-search-none">
							<div class="blog-bottom">
								<h2>Not Found!</h2>
								<p>Sorry! There is no post as your searching keywords.</p>
								<a href="">Go Home</a>
							</div>
						</div>
						
					</div>
					<div class="col-md-4">
						<div class="sidebar-widget">
							<div class="widget">
								<h2>Search</h2>
								<input type="text" placeholder="Search..."/>
							</div>
							
							<div class="widget">
								<h2>Categories</h2>
								<li><a href="">National</a></li>
								<li><a href="">International</a></li>
								<li><a href="">Movie</a></li>
								<li><a href="">Lifestyle</a></li>
								<li><a href="">Travel</a></li>
								<li><a href="">Sports</a></li>
								<li><a href="">News</a></li>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	
	<div class="footer">
		<div class="container">
			<div class="footer-text">
				<p>&copy; 2017- All Rights Reserved By: CodexCoder </p>
			</div>
		</div>
	</div>

      


     


    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="assets/js/jquery-3.2.1.min.js"></script>
    <script src="assets/js/popper.min.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
  </body>
</html>
